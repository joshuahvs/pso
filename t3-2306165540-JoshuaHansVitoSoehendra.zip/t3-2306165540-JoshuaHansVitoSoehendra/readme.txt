Nama: Joshua Hans Vito Soehendra
NPM: 2306165540
Kelas: PSO A
Link Video Youtube: https://youtu.be/GLhIawLJINg

Cara menjalankan program:
1. Buka ubuntu
2. Masuk kedalam direktori yang benar (tugas2)
3. Open terminal
4. Ketikkan perintah "make" di terminal
5. Lalu cek apakah hasil compile "t3" sudah ada dengan perintah 'ls'
6. Jika sudah ada, maka program dapat dijalankan menggunakan perintah "./t3" pada terminal